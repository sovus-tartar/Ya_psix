var searchData=
[
  ['unit_5ftest_0',['unit_test',['../kvadr__head_8h.html#ae6e4db64a57ca6cea2b7242e3e7e1fe7',1,'unit_test(void):&#160;kvadr_test.c'],['../kvadr__test_8c.html#ae6e4db64a57ca6cea2b7242e3e7e1fe7',1,'unit_test(void):&#160;kvadr_test.c']]]
];
