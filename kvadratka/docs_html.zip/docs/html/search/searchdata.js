var indexSectionsWithContent =
{
  0: "abcdefhikmnoprstuxz",
  1: "e",
  2: "ck",
  3: "ceimrsu",
  4: "abcinx",
  5: "r",
  6: "iotz",
  7: "acdfhpst",
  8: "k"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

