var searchData=
[
  ['equation_5fdata_0',['equation_data',['../structequation__data.html',1,'']]]
];
