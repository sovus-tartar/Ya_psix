var searchData=
[
  ['true_0',['TRUE',['../kvadr__head_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'kvadr_head.h']]],
  ['two_5froots_1',['TWO_ROOTS',['../kvadr__head_8h.html#a2cfb9ec67f7eabe94407eefad9ccb048a876622d3c0b008da13a3685c64714e81',1,'kvadr_head.h']]]
];
