var searchData=
[
  ['result_0',['result',['../kvadr__head_8h.html#adc4caf67c06964f872aeed2d531f6873',1,'result(int num, double x1, double x2):&#160;kvadr_func.c'],['../kvadr__func_8c.html#adc4caf67c06964f872aeed2d531f6873',1,'result(int num, double x1, double x2):&#160;kvadr_func.c']]]
];
