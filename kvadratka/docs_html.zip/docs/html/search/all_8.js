var searchData=
[
  ['kvadr_5ffunc_2ec_0',['kvadr_func.c',['../kvadr__func_8c.html',1,'']]],
  ['kvadr_5fhead_2eh_1',['kvadr_head.h',['../kvadr__head_8h.html',1,'']]],
  ['kvadr_5fmain_2ec_2',['kvadr_main.c',['../kvadr__main_8c.html',1,'']]],
  ['kvadr_5ftest_2ec_3',['kvadr_test.c',['../kvadr__test_8c.html',1,'']]],
  ['kvadratka_4',['Kvadratka',['../index.html',1,'']]]
];
