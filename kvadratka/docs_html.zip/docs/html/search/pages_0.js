var searchData=
[
  ['kvadratka_0',['Kvadratka',['../index.html',1,'']]]
];
