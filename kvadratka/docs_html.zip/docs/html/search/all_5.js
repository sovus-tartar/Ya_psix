var searchData=
[
  ['false_0',['FALSE',['../kvadr__head_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'kvadr_head.h']]]
];
