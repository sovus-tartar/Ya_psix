var searchData=
[
  ['a_0',['a',['../structequation__data.html#a1031d0e0a97a340abfe0a6ab9e831045',1,'equation_data']]]
];
