var searchData=
[
  ['solve_5flinear_0',['solve_linear',['../kvadr__head_8h.html#a65f30f388dcae1265ab570394bebd766',1,'solve_linear(double b, double c):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a65f30f388dcae1265ab570394bebd766',1,'solve_linear(double b, double c):&#160;kvadr_func.c']]]
];
