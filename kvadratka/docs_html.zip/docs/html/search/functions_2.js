var searchData=
[
  ['is_5fequal_0',['is_equal',['../kvadr__head_8h.html#a2c44240f345ee0f7f6eeaf24974ce379',1,'is_equal(double val_1, double val_2):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a2c44240f345ee0f7f6eeaf24974ce379',1,'is_equal(double val_1, double val_2):&#160;kvadr_func.c']]]
];
