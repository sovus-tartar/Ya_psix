var searchData=
[
  ['enter_0',['enter',['../kvadr__head_8h.html#aaba0e108dce440ba80503783d377461d',1,'enter(double *a, double *b, double *c):&#160;kvadr_func.c'],['../kvadr__func_8c.html#aaba0e108dce440ba80503783d377461d',1,'enter(double *a, double *b, double *c):&#160;kvadr_func.c']]],
  ['equation_5fsolver_1',['equation_solver',['../kvadr__head_8h.html#aa897e1d598eee5fbbcda78ec3e06ba48',1,'equation_solver(double a, double b, double c, double *x1, double *x2):&#160;kvadr_func.c'],['../kvadr__func_8c.html#aa897e1d598eee5fbbcda78ec3e06ba48',1,'equation_solver(double a, double b, double c, double *x1, double *x2):&#160;kvadr_func.c']]]
];
