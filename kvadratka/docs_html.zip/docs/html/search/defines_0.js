var searchData=
[
  ['accuracy_0',['accuracy',['../kvadr__head_8h.html#a101aad7589a1be0a413b95329f4fdf69',1,'kvadr_head.h']]],
  ['architecture_5fid_1',['ARCHITECTURE_ID',['../_c_make_c_compiler_id_8c.html#aba35d0d200deaeb06aee95ca297acb28',1,'CMakeCCompilerId.c']]]
];
