var searchData=
[
  ['check_5fequation_0',['check_equation',['../kvadr__head_8h.html#a789cf29d5d85da32c897ab3f9c33cec2',1,'check_equation(double a, double b, double c, double x1_expect, double x2_expect, int num_expect):&#160;kvadr_test.c'],['../kvadr__test_8c.html#a789cf29d5d85da32c897ab3f9c33cec2',1,'check_equation(double a, double b, double c, double x1_expect, double x2_expect, int num_expect):&#160;kvadr_test.c']]]
];
