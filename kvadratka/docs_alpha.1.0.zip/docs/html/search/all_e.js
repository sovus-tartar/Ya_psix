var searchData=
[
  ['solve_5flinear_0',['solve_linear',['../kvadr__head_8h.html#a65f30f388dcae1265ab570394bebd766',1,'solve_linear(double b, double c):&#160;kvadr_func.c'],['../kvadr__func_8c.html#ac9ed00de2d71f4149e02b0c467f81c24',1,'solve_linear(const double b, const double c):&#160;kvadr_func.c']]],
  ['square_20equations_20solver_1',['Square equations solver',['../index.html',1,'']]],
  ['stringify_2',['STRINGIFY',['../_c_make_c_compiler_id_8c.html#a43e1cad902b6477bec893cb6430bd6c8',1,'CMakeCCompilerId.c']]],
  ['stringify_5fhelper_3',['STRINGIFY_HELPER',['../_c_make_c_compiler_id_8c.html#a2ae9b72bb13abaabfcf2ee0ba7d3fa1d',1,'CMakeCCompilerId.c']]]
];
