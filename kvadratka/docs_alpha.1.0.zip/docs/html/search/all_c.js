var searchData=
[
  ['platform_5fid_0',['PLATFORM_ID',['../_c_make_c_compiler_id_8c.html#adbc5372f40838899018fadbc89bd588b',1,'CMakeCCompilerId.c']]],
  ['print_5froots_1',['print_roots',['../kvadr__head_8h.html#ae62afdd8abc9d5158052527692fd3c47',1,'print_roots(int root_number, double x1, double x2):&#160;kvadr_func.c'],['../kvadr__func_8c.html#ac44e1d2067e7c1a0c268bff9253d0387',1,'print_roots(const int root_number, const double x1, const double x2):&#160;kvadr_func.c']]],
  ['program_5fexit_2',['program_exit',['../kvadr__head_8h.html#a92ceebccc3a726874918cca2862734b7',1,'program_exit(void):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a92ceebccc3a726874918cca2862734b7',1,'program_exit(void):&#160;kvadr_func.c']]]
];
