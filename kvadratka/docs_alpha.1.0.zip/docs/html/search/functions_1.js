var searchData=
[
  ['equation_5foutput_0',['equation_output',['../kvadr__head_8h.html#ade664241c99d90913d1f1619fcbec214',1,'equation_output(double a, double b, double c):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a85fe464bcda2fa9cf5334d0ff6c45ab3',1,'equation_output(const double a, const double b, const double c):&#160;kvadr_func.c']]],
  ['equation_5fsolver_1',['equation_solver',['../kvadr__head_8h.html#aa897e1d598eee5fbbcda78ec3e06ba48',1,'equation_solver(double a, double b, double c, double *x1, double *x2):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a5534263cd6b749f40ced1c6d04f39817',1,'equation_solver(const double a, const double b, const double c, double *x1, double *x2):&#160;kvadr_func.c']]]
];
