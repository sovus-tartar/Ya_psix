var searchData=
[
  ['variable_5finput_0',['variable_input',['../kvadr__head_8h.html#a038a30ae9d2c9d7428a28e99e0345cf6',1,'variable_input(double *coefficient, int coef_letter):&#160;kvadr_func.c'],['../kvadr__func_8c.html#aed67dbdd6bc8f817201e24e4db631798',1,'variable_input(double *coefficient, const int coef_letter):&#160;kvadr_func.c']]]
];
