var searchData=
[
  ['roots_0',['ROOTS',['../kvadr__head_8h.html#a2cfb9ec67f7eabe94407eefad9ccb048',1,'kvadr_head.h']]]
];
