var searchData=
[
  ['main_0',['main',['../_c_make_c_compiler_id_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;CMakeCCompilerId.c'],['../kvadr__main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;kvadr_main.c']]]
];
