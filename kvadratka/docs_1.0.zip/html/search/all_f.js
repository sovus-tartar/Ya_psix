var searchData=
[
  ['x1_5fexpect_0',['x1_expect',['../structequation__data.html#a3f60e96b2cf28da833999339d953baba',1,'equation_data']]],
  ['x2_5fexpect_1',['x2_expect',['../structequation__data.html#a7c8970969bc8c51125c2d8e35866b7d8',1,'equation_data']]]
];
