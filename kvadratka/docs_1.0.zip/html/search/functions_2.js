var searchData=
[
  ['input_5fcheck_0',['input_check',['../equation_8h.html#a83b6540321f4ff8157362b68951dd726',1,'input_check(char *input):&#160;equation.c'],['../equation_8c.html#a83b6540321f4ff8157362b68951dd726',1,'input_check(char *input):&#160;equation.c']]],
  ['is_5fequal_1',['is_equal',['../equation_8h.html#a2c44240f345ee0f7f6eeaf24974ce379',1,'is_equal(double val_1, double val_2):&#160;equation.c'],['../equation_8c.html#a025407ff1ce82ae96426a6494f3510f6',1,'is_equal(const double val_1, const double val_2):&#160;equation.c']]]
];
