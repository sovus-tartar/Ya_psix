var searchData=
[
  ['a_0',['a',['../structequation__data.html#a1031d0e0a97a340abfe0a6ab9e831045',1,'equation_data']]],
  ['accuracy_1',['ACCURACY',['../equation_8h.html#af270a96662132d0385cb6b4637c5a689',1,'equation.h']]]
];
