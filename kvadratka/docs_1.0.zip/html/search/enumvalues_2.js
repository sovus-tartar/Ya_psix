var searchData=
[
  ['two_5froots_0',['TWO_ROOTS',['../equation_8h.html#a2cfb9ec67f7eabe94407eefad9ccb048a876622d3c0b008da13a3685c64714e81',1,'equation.h']]]
];
