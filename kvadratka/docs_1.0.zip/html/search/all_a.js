var searchData=
[
  ['roots_0',['ROOTS',['../equation_8h.html#a2cfb9ec67f7eabe94407eefad9ccb048',1,'equation.h']]]
];
