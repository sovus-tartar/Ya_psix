var searchData=
[
  ['c_0',['c',['../structequation__data.html#a2c09e929a6ea340fc9653cca414b11d3',1,'equation_data']]],
  ['check_5fequation_1',['check_equation',['../equation_8h.html#a789cf29d5d85da32c897ab3f9c33cec2',1,'check_equation(double a, double b, double c, double x1_expect, double x2_expect, int num_expect):&#160;test.c'],['../test_8c.html#a789cf29d5d85da32c897ab3f9c33cec2',1,'check_equation(double a, double b, double c, double x1_expect, double x2_expect, int num_expect):&#160;test.c']]],
  ['clean_5fbuffer_2',['clean_buffer',['../equation_8h.html#a41cd1acb29d41175fb0e8ba791b26cfe',1,'clean_buffer(void):&#160;equation.c'],['../equation_8c.html#a41cd1acb29d41175fb0e8ba791b26cfe',1,'clean_buffer(void):&#160;equation.c']]],
  ['coefficients_5finput_3',['coefficients_input',['../equation_8h.html#a7df62d9b887d660dcf4c6270381edb7c',1,'coefficients_input(double *a, double *b, double *c):&#160;equation.c'],['../equation_8c.html#a7df62d9b887d660dcf4c6270381edb7c',1,'coefficients_input(double *a, double *b, double *c):&#160;equation.c']]]
];
