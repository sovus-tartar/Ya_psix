var searchData=
[
  ['unit_5ftest_0',['unit_test',['../equation_8h.html#ae6e4db64a57ca6cea2b7242e3e7e1fe7',1,'unit_test(void):&#160;test.c'],['../test_8c.html#ae6e4db64a57ca6cea2b7242e3e7e1fe7',1,'unit_test(void):&#160;test.c']]],
  ['user_5finterface_1',['user_interface',['../equation_8h.html#a2197acd436dd50dc315aec635f97e2c3',1,'user_interface(void):&#160;equation.c'],['../equation_8c.html#a2197acd436dd50dc315aec635f97e2c3',1,'user_interface(void):&#160;equation.c']]]
];
